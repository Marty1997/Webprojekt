import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-club-dashboard',
  templateUrl: './club-dashboard.component.html',
  styleUrls: ['./club-dashboard.component.css']
})
export class ClubDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
