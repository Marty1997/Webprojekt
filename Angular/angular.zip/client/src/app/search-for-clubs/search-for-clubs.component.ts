import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search-for-clubs',
  templateUrl: './search-for-clubs.component.html',
  styleUrls: ['./search-for-clubs.component.css']
})
export class SearchForClubsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
