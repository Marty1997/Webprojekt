import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search-for-players',
  templateUrl: './search-for-players.component.html',
  styleUrls: ['./search-for-players.component.css']
})
export class SearchForPlayersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
