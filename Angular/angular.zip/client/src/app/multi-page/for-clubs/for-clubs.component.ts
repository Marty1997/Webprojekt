import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-for-clubs',
  templateUrl: './for-clubs.component.html',
  styleUrls: ['./for-clubs.component.css']
})
export class ForClubsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
