import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-for-players',
  templateUrl: './for-players.component.html',
  styleUrls: ['./for-players.component.css']
})
export class ForPlayersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
